package com.example.anwar.thingseev1;

/**
 * Created by thath on 5/4/18.
 */

public class Distance {
    public String text;
    public int value;

    public Distance(String text, int value) {
        this.text = text;
        this.value = value;
    }
}

