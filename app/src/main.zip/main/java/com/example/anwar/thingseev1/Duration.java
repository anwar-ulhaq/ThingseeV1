package com.example.anwar.thingseev1;

/**
 * Created by thath on 5/4/18.
 */

public class Duration {
    public String text;
    public int value;

    public Duration(String text, int value) {
        this.text = text;
        this.value = value;
    }
}
